package kr.human.mybatis;

import java.io.File;

public class Test {
	public static void main(String[] args) {
		System.out.println(File.separator);
		System.out.println(File.pathSeparator);
		System.out.println("D:\\1차프로젝트_3조\\오후\\mainbanner (4).jpg".lastIndexOf(File.separator));
	}
}
