-- 실습할 테스트 계정을 만들자
CREATE USER testuser IDENTIFIED BY "123456";
-- 일반적인 권한을 가지고 있는 롤을 이용하여 권한 설정
GRANT CONNECT, resource TO testuser;

