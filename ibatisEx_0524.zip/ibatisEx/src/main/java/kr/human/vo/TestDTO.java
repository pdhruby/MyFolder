package kr.human.vo;

import lombok.Data;

@Data
public class TestDTO {
	private int idx;
	private  String name;
	
}
